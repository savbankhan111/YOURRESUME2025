<?php if($user->roles[0]->id == 1): ?>
    <?php $__env->startSection('page_title', 'Student Details'); ?>
    <?php $__env->startSection('page_name', "Student Detail"); ?>
    <?php $__env->startSection('page_link1', url("admin/dashboard")); ?>
    <?php $__env->startSection('page_name1', "Dashboard"); ?>

    <?php if(optional($user->student->school)->school_type == 'direct'): ?>
        <?php $__env->startSection('page_link2', url("admin/users-list/student")); ?>
        <?php $__env->startSection('page_name2', "List of Student"); ?>
    <?php else: ?>
        <?php $__env->startSection('page_link2', url("admin/users-list/non-student")); ?>
        <?php $__env->startSection('page_name2', "List of Non-Student"); ?>
    <?php endif; ?>
<?php elseif($user->roles[0]->id == 3): ?>
    <?php $__env->startSection('page_title', 'Professional Details'); ?>
    <?php $__env->startSection('page_name', "Professional Detail"); ?>
    <?php $__env->startSection('page_link1', url("admin/dashboard")); ?>
    <?php $__env->startSection('page_name1', "Dashboard"); ?>
    <?php $__env->startSection('page_link2', url("admin/users-list/professional")); ?>
    <?php $__env->startSection('page_name2', "List of Professional"); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid details-page">
        <div class="userimges">
		 <?php if($user->image): ?>
											<div class="imgwraps">  <img width="200" height="200" src="<?php echo e(url('public/uploads/profile/'.$user->image)); ?>" alt="">	 </div>
											 <?php else: ?>
                                             <div class="imgwraps">  <img width="200" height="200" src="<?php echo e(url('/images/user-default.png')); ?>" alt="">	</div> 
											 <?php endif; ?>	

                                             <div class="btnwraps">

											  <a class="btn btntheme" href="<?php echo e(route("admin.userEdit", $user->id)); ?>">Edit</a>										    
										    <?php if($user->status != 'deactivate'): ?>
											   <a class="btn btn-danger" href="<?php echo e(route("admin.changeUserStatuss", $user->id)); ?>" onclick="return confirm('Are you sure?')" ><i class="fa fa-times"></i></a>
									         
                                               <?php endif; ?>	
                                               </div>										 
                                                </div>    


        <div class="card">
             <div class="card-header bg-blue">
                <h5 class="card-title"><?php if($user->roles[0]->id == 1): ?> Student <?php else: ?> Professional <?php endif; ?> Details</h5>
            </div>
            <div class="table-responsive">
                <table  class="table table-striped table-bordered">
                <thead>
                <tr>
					<?php if($user->roles[0]->id == 1): ?>
					 <th scope="col">Group Code</th>	
					<?php endif; ?>	
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
					<?php if($user->roles[0]->id == 3): ?>
					 <th scope="col">Interested industry</th>
					<?php endif; ?>
                    <th scope="col">Status</th>
                    <th scope="col">Email Verified</th>
                </tr>
                </thead>
                <tbody>
                <tr>
				  <?php if($user->roles[0]->id == 1): ?>		
                    <td><?php if(isset($user->student->school->school_code)): ?> <?php echo e($user->student->school->school_code); ?> <?php endif; ?></td>
				  <?php endif; ?>		
                    <td><?php echo e(ucfirst($user->first_name)); ?> <?php echo e($user->last_name); ?></td>
                    <td><?php echo e($user->email); ?></td>
					<td><?php echo e($user->userInfo->contact_no); ?></td> 
					<?php if($user->roles[0]->id == 3): ?>
					 <td><?php echo e($user->professional->interested_industry); ?></td>
                    <?php endif; ?>
					<td><?php if($user->status=='active'): ?> Active <?php elseif($user->status=='deactivate'): ?>Deactivate <?php elseif($user->status=='pending'): ?> Pending <?php else: ?> Suspend <?php endif; ?></td>
                    <td> <?php if($user->email_verified_at==NULL): ?> No <?php elseif($user->email_verified_at!=Null): ?> Yes <?php endif; ?></td>
                </tr>

                </tbody>
            </table>
        </div>
        </div>		
		

        <div class="card">
            <div class="card-header bg-blue">
                <h5 class="card-title"><?php if($user->roles[0]->id == 1): ?> Student <?php else: ?> Professional <?php endif; ?> Address</h5>
            </div>
            <div class="table-responsive">
                <table  class="table table-striped table-bordered">
                <thead>
                <tr>
					<th scope="col">Address</th>
                    <th scope="col">Street Name</th>
                    <th scope="col">City</th>
                    <th scope="col">State</th>
					<th scope="col">ZipCode</th>
                    <th scope="col">Country</th>
                </tr>
                </thead>
                <tbody>
                <tr>
				<td> <?php echo e($user->userAddress->address); ?></td>
                <td> <?php echo e($user->userAddress->street_name); ?></td>
                <td> <?php echo e($user->userAddress->city); ?></td>
                <td><?php if($user->userAddress->stateInfo): ?> <?php echo e($user->userAddress->stateInfo->name); ?><?php else: ?> <?php echo e($user->userAddress->province); ?><?php endif; ?></td>
				<td><?php echo e($user->userAddress->zipcode); ?></td>
                <td><?php if($user->userAddress->countryInfo): ?> <?php echo e($user->userAddress->countryInfo->name); ?><?php else: ?> <?php echo e($user->userAddress->country); ?><?php endif; ?></td>				
                </tr>
                </tbody>
            </table>
        </div>
        </div>
 
			<div class="card">
		<?php if($user->roles[0]->id == 1): ?>

       
            <!-- student-->
             <div class="card-header bg-blue">
                <h5 class="card-title">Student Profile</h5>
            </div>
            <div class="table-responsive">
                <table  class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th scope="col">Major</th>
                    <th scope="col">Indication</th>
                    <th scope="col">Graduation Completion Date</th>
                    <th scope="col">Other</th>
					<th scope="col">Minor</th>
                    <th scope="col">School/College Name</th>
					<th scope="col">ID Card</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo e($user->student->major); ?></td>
                    <td><?php echo e($user->student->indication); ?></td>
                    <td><?php echo e(date('M d,Y', strtotime($user->student->graduation_date))); ?></td>
                    <td><?php echo e($user->student->other); ?></td>
					<td><?php echo e($user->student->minor); ?></td>
					<?php if($user->student->school): ?>
                     <td><?php echo e($user->student->school->school_name); ?></td>
					<?php else: ?>
					 <td><?php echo e($user->student->school_name); ?></td>
					<?php endif; ?>	
					<td>
                    
					 <?php if($user->student->school_proff_id): ?>
					  <img width="100" height="100" src="<?php echo e(url('public/uploads/profile/'.$user->student->school_proff_id)); ?>" alt="">
					 <?php endif; ?>
					</td>
                </tr>
                
                </tbody>
            </table>
        </div>     
		<?php endif; ?>	
		</div>
		
		<?php if($user->roles[0]->id == 1 || $user->roles[0]->id == 3): ?>
		<div class="card">
		<div class="card-header bg-blue">
                <h5 class="card-title ">Payment History</h5>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                <thead>
                <tr>
					<th scope="col">Order ID</th>
                    <th scope="col">Payment Type</th>
                    <th scope="col">Start Date</th>
                    <th scope="col">Expire Date</th>					
					<th scope="col">Plan Option</th>
					<th scope="col">Total Interview</th>					
                    <th scope="col">Total Amount</th>
                </tr>
                </thead>
                <tbody>	
		      <?php $__empty_1 = true; $__currentLoopData = $user->userOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>		  
                <tr>
					<td>#<?php echo e($uo->id); ?></td>
                    <td><?php echo e(ucfirst($uo->payment_type)); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($uo->start_date))); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($uo->end_date))); ?></td>
					<td><?php echo $uo->plan_option =  '0' ? 'Plan' : 'Purchase Interview'; ?></td>
					<td><?php echo e($uo->total_interview); ?></td>
                    <td><?php echo e($uo->total_amount); ?></td>
                </tr>
			   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="500"><h2 style="padding:20px ;text-align: center;">No record Found</h2></td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
            </div>
		</div>		
	   <?php endif; ?>

    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\YOURRESUME2025\resources\views/admin/userlist/user_details.blade.php ENDPATH**/ ?>