<aside class="left-sidebar  admin-sidebar" data-sidebarbg="skin5">
  
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav" class="p-t-30">
		<?php if(Auth::user()->checkRole("interviewer_manager")): ?>
			
            <?php echo $__env->make("layouts.all.manager_int.partial.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif(Auth::user()->checkRole("employer")): ?>
		 
            <?php echo $__env->make("layouts.all.crm.partial.asidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endif; ?>
				
			</ul>		
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>

<?php /**PATH C:\wamp64\www\YOURRESUME2025\resources\views/layouts/all/asidebar.blade.php ENDPATH**/ ?>