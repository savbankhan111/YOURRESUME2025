<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($message); ?></strong>
    </div>
<?php endif; ?><?php /**PATH C:\wamp64\www\YOURRESUME2025\resources\views/admin/partials/success_msg.blade.php ENDPATH**/ ?>