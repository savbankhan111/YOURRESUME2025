<?php $__env->startSection('page_title','List of Employer'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Container fluid  -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="align-items-center">

                          <div class="row">
                              <div class="col-md-12">
                                  <?php echo $__env->make("admin.partials.success_msg", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                  <form action="" method="get">
                                    <div class="row">
									<div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="">Status</label>
                                                    <select id="status" name="status" class="form-control fsubmit">
													<option value="">All</option>
														<option value="active" <?php if('active' == Request::get('status')): ?> selected <?php endif; ?> >Active</option>
														<option value="deactivate" <?php if('deactivate' == Request::get('status')): ?> selected <?php endif; ?> >Deactivate</option>
														<option value="suspend" <?php if('suspend' == Request::get('status')): ?> selected <?php endif; ?> >Suspend</option>
														
                                                    </select>
                                                </div>
                                    </div>
                                    </div>
                                  </form>

                              </div>
                             <div class="col-md-12">
                                  <div class="table-responsive">
                                  <table  class="table table-striped table-bordered">
                                      <thead>
                                      <tr>
                                          <th>Name</th>
                                          <th>Email</th>
                                          <th>Contact number</th>
                                            <th>Expire Date</th>
                                          <th>Status</th>
                                          <th>Action</th>
                                      </tr>
                                      </thead>
                                      <tbody>

                                     <?php $__empty_1 = true; $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                         <tr>
											<td><?php echo e(ucfirst($cand->first_name)); ?> <?php echo e($cand->last_name); ?></td>
											<td><?php echo e($cand->email); ?></td>
											<td><?php echo e($cand->employerInfo->phone_number); ?></td>
												<td><?php echo substr($cand->employerInfo->expire_ac,0,10 ); ?></td>
                                            <td>
											  <form method="POST" action="<?php echo e(route('admin.changeUserStatus',$cand->id)); ?>" accept-charset="UTF-8">
											    <?php echo csrf_field(); ?>	 
                                                 <select  name="status" id="status" onchange="if(confirm('Do you want to perform this?')){this.form.submit();}">                                                												
                                                      <option value="active" <?php echo e($cand->status== 'active'? "selected":""); ?> >Activate</option>
                                                      <option value="deactivate" <?php echo e($cand->status== 'deactivate'? "selected":""); ?>>Deactivate</option>
                                                      <option value="suspend" <?php echo e($cand->status== 'suspend'? "selected":""); ?>>Suspend</option> 
                                                 </select>
											  </form>
                                            </td>
                                            <td><a class="btn btntheme" href="<?php echo e(route('admin.editEmployer', $cand->id)); ?>">Edit</a>  <a class="btn btntheme" href="<?php echo e(route('admin.detailsEmployer', $cand->id)); ?>">Detail</a>
                                              <?php if($cand->status != 'deactivate'): ?>
											   <a class="btn btn-danger" href="<?php echo e(route("admin.changeUserStatus", $cand->id)); ?>" onclick="return confirm('Are you sure?')" ><i class="fa fa-trash-o"></i></a>
									            <?php endif; ?>
                                           
                                         </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                         <tr>
                                         <td colspan="500"> <h2 style="padding:20px ;text-align: center;">No data Found</h2>
                                         </td>
                                         </tr>
                                      <?php endif; ?>
                                       
                                      </tbody>

                                  </table>                               

                                      <?php echo $candidates->appends(request()->except('page'))->links(); ?>

                                  </div>
                              </div>

                          </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
      </div>
    <script type="application/javascript">
        $(document).ready(function(){
            $('.fsubmit').change(function() {
                this.form.submit();
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\YOURRESUME2025\resources\views/admin/employer/employer_list.blade.php ENDPATH**/ ?>