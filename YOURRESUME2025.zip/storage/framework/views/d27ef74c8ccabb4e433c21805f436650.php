<footer class="footer" style="text-align: center">
    All Rights Reserved by ResumeLive.
</footer>
<?php /**PATH C:\wamp64\www\YOURRESUME2025\resources\views/layouts/all/footer.blade.php ENDPATH**/ ?>