<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('page_title'); ?></title>
 

    
    
      <link rel="icon" type="image/png" href="<?php echo e(asset('images/fev.png')); ?>"/>
   
<link rel="icon" type="image/png" href="<?php echo e(asset('images/fev.png')); ?>"/>
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet">
    
    <link href="<?php echo e(asset('css/bootstrap-datepicker.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-slider.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/jquery.simple-dtpicker.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="//cdn.materialdesignicons.com/4.4.95/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-slider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.simple-dtpicker.js')); ?>"></script>

    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
</head>
<body>


<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
    <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
    </div>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper">
    <!-- ============================================================== -->
    <!-- Topbar header - style you can find in pages.scss -->
    <!-- ============================================================== -->

<?php echo $__env->make("layouts.all.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ============================================================== -->
    <!-- End Topbar header -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->

<?php echo $__env->make("layouts.all.asidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ============================================================== -->
    <!-- End Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Page wrapper  -->
    <div class="page-wrapper">

        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-12   no-block align-items-center">
                    <h4 class="page-title"><?php echo $__env->yieldContent('page_title'); ?> <a class="float-right pageurl" href="<?php echo $__env->yieldContent('page_link'); ?>"><?php echo $__env->yieldContent('page_name'); ?></a></h4>
                    <div class="ml-auto text-right">
                        <nav aria-label="breadcrumb">

                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-12 no-block align-items-center">
                    <h4 class="page-title">
                        
                      
                        <?php
                        $role = Auth::user()->roles->first();
                    ?>
                    
                    <?php if(Auth::check() && $role && $role->roles == 'employer'): ?>
                        <a class="pageurl" href="<?php echo e(route('employer.dashbords')); ?>">Dashboard</a>
                    <?php elseif(Auth::check() && $role && $role->roles == 'interviewer_manager'): ?>
                        <a class="pageurl" href="<?php echo e(url('interviewsdata')); ?>">Dashboard</a>
                    <?php endif; ?>
                    

                        
                        <?php if(View::hasSection('page_link2')): ?> /
                            <a class="pageurl" href="<?php echo $__env->yieldContent('page_link2'); ?>"><?php echo $__env->yieldContent('page_name2'); ?></a>
                        <?php endif; ?>
                        
                        
                        <?php if(View::hasSection('page_title')): ?>
                            / <?php echo $__env->yieldContent('page_title'); ?>
                        <?php endif; ?>
                    </h4>
                </div>
            </div>
        </div>
        
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->

    <?php echo $__env->yieldContent('content'); ?>

        <!-- Content Header (Page header) -->

        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->





<?php echo $__env->make("layouts.all.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ============================================================== -->
    <!-- End footer -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<!-- ============================================================== -->
</div>

<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset('js/all.js')); ?>"></script>

<?php echo $__env->make('admin.ajax.reuseajax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>

    $('#zero_config').DataTable();
    $(document).ready(function() {
        let url = "";
    });


</script>
 <?php echo $__env->yieldContent('footerScript'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\YOURRESUME2025\resources\views/layouts/all/crm.blade.php ENDPATH**/ ?>