<?php if(sizeof($candidates) > 0 && $candidates[0]->roles[0]->id == 1): ?> 
 <?php $__env->startSection('page_title','List of Students'); ?>	
<?php elseif(sizeof($candidates) > 0 && $candidates[0]->roles[0]->id == 3): ?> 
 <?php $__env->startSection('page_title','List of Professional'); ?>	
<?php else: ?>	
 <?php $__env->startSection('page_title','List of Users'); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>

    <!-- Container fluid  -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="align-items-center">

                          <div class="row">
                              <div class="col-md-12">
                                  <?php echo $__env->make("admin.partials.success_msg", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                  <form action="" method="get">
                                    <div class="row">
	<div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="">Status</label>
                                                    <select id="status" name="status" class="form-control fsubmit">
													<option value="">All</option>
														<option value="active" <?php if('active' == Request::get('status')): ?> selected <?php endif; ?> >Active</option>
														<option value="deactivate" <?php if('deactivate' == Request::get('status')): ?> selected <?php endif; ?> >Deactivate</option>
														<option value="pending" <?php if('pending' == Request::get('status')): ?> selected <?php endif; ?> >Pending</option>
														
                                                    </select>
                                                </div>
                                    </div>
<?php if(Request::url()==route("admin.userListBy","student")): ?>

                                            <div class="col-md-3">

                                                <div class="form-group">
                                                    <label for="">Select School/College</label>

                                                    <select id="school" name="school" class="form-control fsubmit">
                                                        <option value="change">All</option>
												<?php if(sizeof($schools) >0): ?>		
                                                 <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option <?php echo e($school->id == Request::get('school')? "selected":""); ?> value="<?php echo e($school->id); ?>"> <?php echo e($school->school_name); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
<?php endif; ?>					
		
                                    </div>

                                  </form>

                              </div>
                             <div class="col-md-12">
                                  <div class="table-responsive">
                                  <table  class="table table-striped table-bordered">
                                      <thead>
                                      <tr>
                                          <th>Image</th>
                                          <th>Name</th>
										  
										   <?php if(sizeof($candidates) > 0 && $candidates[0]->roles[0]->id == 1): ?> 
											   <th>School/College Name</th>
										    
										   <?php endif; ?>
                                          <th>Email</th>
										  <?php if(sizeof($candidates) > 0 && $candidates[0]->roles[0]->id == 4): ?>
											   <th>Total Members</th>
										  <?php endif; ?>
										  
                                          <th>Status</th>
                                         
										  
                                          <th>Action</th>
                                      </tr>
                                      </thead>
                                      <tbody>

                                     <?php $__empty_1 = true; $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                         <tr>
                                             <td> 
											 <?php if($cand->image): ?>
											  <img width="80" height="80" src="<?php echo e(url('public/uploads/profile/'.$cand->image)); ?>" alt="">	 
											 <?php else: ?>
											  <img width="80" height="80" src="<?php echo e(url('/images/user-default.png')); ?>" alt="">	 
											 <?php endif; ?>	 
											 </td>

                                             <td><?php echo e(ucfirst($cand->first_name)); ?> <?php echo e($cand->last_name); ?></td>
                                          <?php if($candidates[0]->roles[0]->id == 1): ?> 
											<td>
										     <?php if($cand->student->school_id): ?><?php echo e($cand->student->school->school_name); ?><?php else: ?> <?php echo e($cand->student->school_name); ?> <?php endif; ?>
										    </td> 
											
										  <?php endif; ?>
										  
                                             <td><?php echo e($cand->email); ?></td>
										  <?php if(sizeof($candidates) > 0 && $candidates[0]->roles[0]->id == 4): ?>
											   <td><?php echo e(sizeof($cand->school->student)); ?></td>
										  <?php endif; ?>
										   
										 
                                            <td>
											<form method="POST"  action="<?php echo e(route('admin.changeUserStatus',$cand->id)); ?>" accept-charset="UTF-8">
											 <?php echo csrf_field(); ?>	 
                                                <select  name="status" id="status" onchange="if(confirm('Do you want to perform this?')){this.form.submit();}" >
                                                    <option value="active" <?php echo e($cand->status== 'active'? "selected":""); ?> >Active</option>
                                                    <option value="deactivate" <?php echo e($cand->status== 'deactivate'? "selected":""); ?>>Deactivate</option>
                                                    <option value="pending" <?php echo e($cand->status== 'pending'? "selected":""); ?>>Pending</option>
                                                </select>
											</form>

                                             </td>
                                           
                                             <td> 
											  <a class="btn btntheme" href="<?php echo e(route("admin.userDetails", $cand->id)); ?>">Details</a>
											<?php if(sizeof($candidates) > 0 && $candidates[0]->roles[0]->id == 1): ?>
											  <a class="btn btntheme" href="<?php echo e(route("admin.editStudent", $cand->id)); ?>">Edit</a>												
											<?php else: ?>
											  <a class="btn btntheme" href="<?php echo e(route("admin.userEdit", $cand->id)); ?>">Edit</a>
										    <?php endif; ?>
										    
										    <?php if($cand->status != 'deactivate'): ?>
											   <a class="btn btn-danger" href="<?php echo e(route("admin.changeUserStatuss", $cand->id)); ?>" onclick="return confirm('Are you sure?')" ><i class="fa fa-trash-o"></i></a>
									            <?php endif; ?>
										    
												  
											 </td>


                                         </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                         <tr>
                                         <td colspan="500"> <h2 style="padding:20px ;text-align: center;">No User Found</h2>
                                         </td>


                                         </tr>
                                        <?php endif; ?>
                                       
                                      </tbody>

                                  </table>                               

                                      <?php echo $candidates->appends(request()->except('page'))->links(); ?>

                                  </div>
                              </div>

                          </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
      </div>
    <script type="application/javascript">
        $(document).ready(function(){
            $('.fsubmit').change(function() {
                this.form.submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\YOURRESUME2025\resources\views/admin/userlist/users_list.blade.php ENDPATH**/ ?>