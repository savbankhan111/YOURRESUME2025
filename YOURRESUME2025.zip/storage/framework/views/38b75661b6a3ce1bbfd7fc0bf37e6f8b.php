<?php $__env->startSection('page_title',"Project Add"); ?>
<?php $__env->startSection('page_name',"Project List"); ?>
<?php $__env->startSection('page_link',route("employer.projectListBy")); ?>
<?php $__env->startSection('content'); ?>
     <div class="container-fluid">
            <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="align-items-center">

                          <div class="">

                              <?php echo $__env->make("admin.partials.error_forms", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                              <?php echo $__env->make("admin.partials.success_msg", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form method="POST" action="<?php echo e(route('employer.storeProject')); ?>" class="form-horizontal m-t-20" enctype="multipart/form-data">
						<input name="_method" type="hidden" value="PUT">
                        <?php echo csrf_field(); ?>
                                  <div class="row">
								  <div class="col-md-12">
                                    <div class="form-group">
                                      <label for="">Project</label>
                                      <input value="" type="text" name="name" class="form-control" required >
                                    </div>
								  </div>

                                
								<div class="col-md-12">
                                  <div class="form-group">
                                      <label for="">About this project</label>
                                      <textarea name="description" class="form-control" rows="6" required ></textarea>
                                  </div>
                                </div>
								
								 <div class="col-md-6">
                                  <div class="form-group">
                                      <label for="">Project Status</label>
									  <select name="project_status" id="project_status" class="form-control">
										<option value="open">Open</option>
										<option value="pending">Pending</option>
                                        <option value="under_progress">Under Progress</option>
                                        <option value="close">Close</option>											
                                        <option value="complete">Complete</option>
                                      </select>
                                  </div>
                                  </div>
								 <div class="col-md-6">
                                  <div class="form-group">
                                      <label for="">Status</label>
									  <select  name="status" id="status" class="form-control">									  
										<option value="publish">Publish</option>
                                        <option value="draft">Draft</option>
										<option value="trash">Trash</option>
                                      </select>
                                  </div>
                                  </div>

                         <div class="col-md-12">
                             <div class="form-group">
							      <button class="themebtnmain">Create</button>
                             </div>
                        </div>
                                  </div>
                      </form>

                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
	
<?php $__env->startSection('footerScript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.all.crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\YOURRESUME2025\resources\views/employer/project_add.blade.php ENDPATH**/ ?>