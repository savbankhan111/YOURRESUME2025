<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid dashboard-page">
        <!-- ============================================================== -->
        <!-- Sales Cards  -->
        <!-- ============================================================== -->
        <div class="row" style="margin-top: 20px;">
            <!-- Column -->
                <!-- Column -->
                <div class="col-md-3 col-lg-3">
                    <div class="card card-hover">
                        <div class="box text-center">
                            <h1 class="font-light text-white"><?php echo e($stuTotals->users_count); ?></h1>
                            <h6 class="text-white">Total Students</h6>
                        </div>
                    
                <div class="card-body">
                    <h5 class="card-title m-b-0">Students</h5>
                </div>
                <table class="table">
                    <tbody>
                    <tr>
                        <td scope="col">Total Active</td>
                        <td scope="col"><span class="badge badge-success"> <?php echo e($stuTotals->user_active_total_count); ?></span></td>
                    </tr>
                    <tr>
                        <td>Total Deactivate </td>
                        <td><span class="badge badge-warning"><?php echo e($stuTotals->user_disabled_total_count); ?> </span></td>
                    </tr>
					<tr>
                        <td scope="col">Total Pending</td>
                        <td scope="col"><span class="badge badge-success"> <?php echo e($stuTotals->user_pending_total_count); ?></span></td>
                    </tr>
                    </tbody>
                </table>
            </div>
                </div>
                <!-- Column -->
                <div class="col-md-3 col-lg-3">
                    <div class="card card-hover">
                        <div class="box text-center">
                            <h1 class="font-light text-white"><?php echo e($empTotals->users_count); ?></h1>
                            <h6 class="text-white">Total Employees</h6>
                        </div>
                 
                <div class="card-body">
                    <h5 class="card-title m-b-0">Employees</h5>
                </div>
                <table class="table">
                    <tbody>
                    <tr>
                        <td scope="col">Total Active</td>
                        <td scope="col"><span class="badge badge-success"> <?php echo e($empTotals->user_active_total_count); ?></span></td>
                    </tr>
                    <tr>
                        <td>Total Deactivate </td>
                        <td><span class="badge badge-warning"><?php echo e($empTotals->user_disabled_total_count); ?> </span></td>
                    </tr>
					<tr>
                        <td scope="col">Total Pending</td>
                        <td scope="col"><span class="badge badge-success"> <?php echo e($empTotals->user_pending_total_count); ?></span></td>
                    </tr>
                    </tbody>
                </table>
            </div>
                </div>   <!-- Column -->
                <div class="col-md-3 col-lg-3">
                    <div class="card card-hover">
                        <div class="box text-center">
                            <h1 class="font-light text-white"><?php echo e($profTotals->users_count); ?></h1>
                            <h6 class="text-white">Total Professionals</h6>
                        </div>
                     
                    <div class="card-body">
                        <h5 class="card-title m-b-0">Professionals</h5>
                    </div>
                    <table class="table">

                        <tbody>
                        <tr>
                            <td>Total Active </td>
                            <td><span class="badge badge-success"><?php echo e($profTotals->user_active_total_count); ?> </span></td>
                        </tr>
                        <tr>
                            <td>Total Deactivate</td>
                            <td><span class="badge badge-warning"><?php echo e($profTotals->user_disabled_total_count); ?></span></td>
                        </tr>
						<tr>
                        <td scope="col">Total Pending</td>
                        <td scope="col"><span class="badge badge-success"> <?php echo e($profTotals->user_pending_total_count); ?></span></td>
                    </tr>
                        </tbody>
                    </table>
                </div>
                </div>
                <!-- Column -->
				<div class="col-md-3 col-lg-3">
                    <div class="card card-hover">
                        <div class="box text-center">
                            <h1 class="font-light text-white"><?php echo e($mangTotals->users_count); ?></h1>
                            <h6 class="text-white">Total Recruitment Managers</h6>
                        </div>
                    
                    <div class="card-body">
                        <h5 class="card-title m-b-0">Managers</h5>
                    </div>
                    <table class="table">

                        <tbody>
                        <tr>
                            <td>Total Active </td>
                            <td><span class="badge badge-success"><?php echo e($mangTotals->user_active_total_count); ?> </span></td>
                        </tr>
                        <tr>
                            <td>Total Deactivate</td>
                            <td><span class="badge badge-warning"><?php echo e($mangTotals->user_disabled_total_count); ?></span></td>
                        </tr>
						<tr>
                        <td scope="col">Total Suspend</td>
                        <td scope="col"><span class="badge badge-success"> <?php echo e($mangTotals->user_suspend_total_count); ?></span></td>
                    </tr>
                        </tbody>
                    </table>
                </div>
                </div>
                <!-- Column -->
        </div>
		 
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\YOURRESUME2025\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>