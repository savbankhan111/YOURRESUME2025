<body>
<p><h2> Hi {{$name}},</h2><br>
	 {!!$mess!!}.
	 </p>
<p>Thanks for your support!<br/>
© <?php echo date("Y"); ?> <a href="{{url('/')}}">ResumeLive</a> All rights reserved.
</p>	 
</body>