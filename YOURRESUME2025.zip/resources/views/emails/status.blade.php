<table style="border:none; width:500px;max-width: 100%;margin: 0 auto;">
	<thead style="background: #1a5eaf;"><tr style="border:none;"><td style="border:none;padding: 15px;text-align: center;"><img style="height: 100px;" src="https://shimlaexpress.com/resumelive21/public/images/logo-icon.png" alt=""></td></tr></thead>
	<tbody style="background: #f2f2f2;">
		<tr style="border:none;">
			<td style="border:none;padding: 15px;text-align: left;">
				<h2 style="font-size: 25px; margin-top: 0px; margin-bottom: 9px;">Hello, {{ $name }}</h2>
				<p style="margin: 0px;font-size: 16px;">{{ $mess }}</p>
				<p style="margin: 0px;font-size: 16px;">Thank you.</p>
			</td>
		</tr>
	</tbody>
</table> 