<body>
<div><h2> Hello!,</h2>
You are receiving this email because we received a password reset request for your account.<br><br>
<a href="{!! url($mess)!!}" style="box-sizing:border-box;border-radius:4px;color:#fff;display:inline-block;overflow:hidden;text-decoration:none;background-color:#2d3748;border-bottom:8px solid #2d3748;border-left:18px solid #2d3748;border-right:18px solid #2d3748;border-top:8px solid #2d3748">Reset Password</a>

<br>
If you did not request a password reset, no further action is required.	<br>
	 </div>
<p><b>Regards,</b><br>
ResumeLive<br/>
© <?php echo date("Y"); ?> <a href="{{url('/')}}">ResumeLive</a> All rights reserved.
</p>	 
</body>