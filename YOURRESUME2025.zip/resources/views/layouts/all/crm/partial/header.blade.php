<a class="dropdown-item profile-page" href="{{route('employer.profile')}}">
    <i class="ti-user m-r-5 m-l-5"></i> My Profile</a>