<footer class="footer" style="text-align: center">
    All Rights Reserved by ResumeLive.
</footer>
